import React, { Component }  from 'react';

const EmptyScreen = () => {
    return (
        <main>
            
        </main>
    );
}
export default EmptyScreen;