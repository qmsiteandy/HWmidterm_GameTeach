import { createContext } from "react";

const DispatchContext = createContext();
const StateContext = createContext();

export { DispatchContext, StateContext }